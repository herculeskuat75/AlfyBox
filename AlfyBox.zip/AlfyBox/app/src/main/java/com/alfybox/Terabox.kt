package com.alfybox

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.io.InputStream
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/** Upload ke Terabox: Rapid Upload dulu, kalau gagal baru Chunked Upload. */
object Terabox {
    private const val HOST = "www.terabox.com"
    private const val DEFAULT_UP_HOST = "c-jp.terabox.com"
    private const val APP_ID = "250528"
    private const val CHUNK = 4 * 1024 * 1024
    private const val SLICE = 256 * 1024
    private const val UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Safari/537.36"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .build()

    class Fail(msg: String) : Exception(msg)

    private class Hashes(
        val size: Long,
        val content: String,
        val slice: String,
        val blocks: List<String>
    )

    // ---------------------------------------------------------------- public

    fun fileName(ctx: Context, uri: Uri): String = meta(ctx, uri).first

    /** onProgress(status, fraksi). fraksi < 0 = indeterminate. */
    suspend fun upload(
        ctx: Context,
        uri: Uri,
        rawCookie: String,
        onProgress: (String, Float) -> Unit
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            Result.success(run(ctx, uri, cookieOf(rawCookie), onProgress))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------------------------------------------------------------- alur utama

    private fun run(
        ctx: Context,
        uri: Uri,
        cookie: String,
        progress: (String, Float) -> Unit
    ): String {
        if (cookie.isBlank()) throw Fail("Cookie kosong")
        if (cookie.any { it.code !in 32..126 }) throw Fail("Cookie mengandung karakter tidak valid")

        val (rawName, knownSize) = meta(ctx, uri)
        val name = rawName.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        val path = "/$name"
        val now = (System.currentTimeMillis() / 1000).toString()

        // 1. Hash (MD5 penuh, MD5 256KB pertama, MD5 tiap chunk) dalam satu kali baca
        progress("Hash 0%", 0f)
        val h = hash(ctx, uri, knownSize) { progress("Hash ${(it * 100).toInt()}%", it) }
        if (h.size == 0L) throw Fail("File kosong")

        // 2. Validasi cookie + ambil bdstoken
        progress("Cek cookie…", -1f)
        val token = bdstoken(cookie)

        // 3. Rapid upload
        progress("Rapid upload…", -1f)
        if (tryRapid(cookie, token, path, h, now)) {
            progress("Selesai (rapid)", 1f)
            return "Selesai (rapid upload): $name"
        }

        // 4. Chunked upload
        progress("Siapkan upload…", -1f)
        val blockJson = JSONArray(h.blocks).toString()
        val pre = json(
            req(
                api("precreate", token), cookie,
                FormBody.Builder()
                    .add("path", path)
                    .add("autoinit", "1")
                    .add("target_path", "/")
                    .add("block_list", blockJson)
                    .add("size", h.size.toString())
                    .add("local_mtime", now)
                    .add("local_ctime", now)
                    .add("rtype", "1")
                    .build()
            )
        )
        val preErr = pre.optInt("errno", -1)
        if (preErr != 0) throw Fail("Precreate gagal (errno $preErr)")
        val uploadId = pre.optString("uploadid")
        if (uploadId.isEmpty()) throw Fail("uploadid kosong dari server")

        val all = h.blocks.indices.toSet()
        val need: Set<Int> = pre.optJSONArray("block_list")
            ?.let { a -> (0 until a.length()).map { a.getInt(it) }.toSet() }
            ?.takeIf { it.isNotEmpty() } ?: all

        val upHost = uploadHost(cookie, path, uploadId)
        var done = 0L
        stream(ctx, uri).use { ins ->
            val buf = ByteArray(CHUNK)
            for (i in h.blocks.indices) {
                val n = ins.fill(buf)
                if (n <= 0) throw Fail("Gagal membaca file")
                if (i in need) putChunk(cookie, upHost, path, uploadId, i, buf, n)
                done += n
                progress("Upload ${i + 1}/${h.blocks.size}", done.toFloat() / h.size)
            }
        }

        // 5. Finalisasi
        progress("Finalisasi…", 1f)
        val fin = json(
            req(
                api("create", token), cookie,
                FormBody.Builder()
                    .add("path", path)
                    .add("size", h.size.toString())
                    .add("uploadid", uploadId)
                    .add("target_path", "/")
                    .add("block_list", blockJson)
                    .add("isdir", "0")
                    .add("rtype", "1")
                    .add("local_mtime", now)
                    .add("local_ctime", now)
                    .build()
            )
        )
        val finErr = fin.optInt("errno", -1)
        if (finErr != 0) throw Fail("Finalisasi gagal (errno $finErr)")
        progress("Selesai", 1f)
        return "Selesai (chunked upload): $name"
    }

    // ---------------------------------------------------------------- langkah API

    private fun bdstoken(cookie: String): String {
        val j = json(req(api("gettemplatevariable", null, "fields" to "[\"bdstoken\"]"), cookie))
        val e = j.optInt("errno", -1)
        if (e != 0) throw Fail("Cookie tidak valid / kedaluwarsa (errno $e)")
        return j.optJSONObject("result")?.optString("bdstoken").orEmpty()
    }

    private fun tryRapid(cookie: String, token: String, path: String, h: Hashes, now: String): Boolean {
        val body = FormBody.Builder()
            .add("path", path)
            .add("content-length", h.size.toString())
            .add("content-md5", h.content)
            .add("slice-md5", h.slice)
            .add("local_ctime", now)
            .add("local_mtime", now)
            .add("rtype", "1")
            .build()
        return try {
            json(req(api("rapidupload", token), cookie, body)).optInt("errno", -1) == 0
        } catch (e: IOException) {
            false
        } catch (e: Fail) {
            false
        }
    }

    private fun uploadHost(cookie: String, path: String, uploadId: String): String = try {
        val url = "https://d.terabox.com/rest/2.0/pcs/file".toHttpUrl().newBuilder()
            .addQueryParameter("method", "locateupload")
            .addQueryParameter("appid", APP_ID)
            .addQueryParameter("path", path)
            .addQueryParameter("uploadid", uploadId)
            .addQueryParameter("upload_version", "2.0")
            .build()
        json(req(url, cookie)).optString("host")
            .removePrefix("https://").trimEnd('/')
            .ifEmpty { DEFAULT_UP_HOST }
    } catch (e: Exception) {
        DEFAULT_UP_HOST
    }

    private fun putChunk(
        cookie: String,
        host: String,
        path: String,
        uploadId: String,
        index: Int,
        buf: ByteArray,
        len: Int
    ) {
        val url = "https://$host/rest/2.0/pcs/superfile2".toHttpUrl().newBuilder()
            .addQueryParameter("method", "upload")
            .addQueryParameter("app_id", APP_ID)
            .addQueryParameter("channel", "dubox")
            .addQueryParameter("clienttype", "0")
            .addQueryParameter("web", "1")
            .addQueryParameter("path", path)
            .addQueryParameter("uploadid", uploadId)
            .addQueryParameter("uploadsign", "0")
            .addQueryParameter("partseq", index.toString())
            .build()

        var err = "tidak diketahui"
        for (attempt in 1..3) {
            try {
                val body = MultipartBody.Builder().setType(MultipartBody.FORM)
                    .addFormDataPart(
                        "file", "blob",
                        buf.toRequestBody("application/octet-stream".toMediaType(), 0, len)
                    )
                    .build()
                val j = json(req(url, cookie, body))
                if (j.optString("md5").isNotEmpty()) return
                err = j.optString("error_msg").ifEmpty {
                    "kode ${j.optInt("error_code", j.optInt("errno", 0))}"
                }
            } catch (e: IOException) {
                err = e.message ?: "jaringan"
            } catch (e: Fail) {
                err = e.message ?: "respons"
            }
            if (attempt < 3) Thread.sleep(1000L * attempt)
        }
        throw Fail("Chunk ${index + 1} gagal: $err")
    }

    // ---------------------------------------------------------------- helper HTTP

    private fun api(path: String, token: String?, vararg q: Pair<String, String>): HttpUrl {
        val b = "https://$HOST/api/$path".toHttpUrl().newBuilder()
            .addQueryParameter("app_id", APP_ID)
            .addQueryParameter("web", "1")
            .addQueryParameter("channel", "dubox")
            .addQueryParameter("clienttype", "0")
        if (token != null) b.addQueryParameter("bdstoken", token)
        q.forEach { b.addQueryParameter(it.first, it.second) }
        return b.build()
    }

    private fun req(url: HttpUrl, cookie: String, body: RequestBody? = null): Request {
        val b = Request.Builder().url(url)
            .header("Cookie", cookie)
            .header("User-Agent", UA)
            .header("Referer", "https://$HOST/main")
            .header("Origin", "https://$HOST")
        return (if (body != null) b.post(body) else b.get()).build()
    }

    private fun json(r: Request): JSONObject =
        client.newCall(r).execute().use { res ->
            val s = res.body?.string().orEmpty()
            try {
                JSONObject(s)
            } catch (e: Exception) {
                throw Fail("Respons tidak valid (HTTP ${res.code}), cek cookie")
            }
        }

    private fun cookieOf(raw: String): String {
        val c = raw.replace("\r", " ").replace("\n", " ").trim()
            .removePrefix("Cookie:").trim()
        return if (c.isEmpty() || c.contains('=')) c else "ndus=$c"
    }

    // ---------------------------------------------------------------- helper file

    private fun meta(ctx: Context, uri: Uri): Pair<String, Long> {
        var name: String? = null
        var size = -1L
        ctx.contentResolver.query(
            uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null
        )?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (ni >= 0) name = c.getString(ni)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
            }
        }
        val n = name?.takeIf { it.isNotBlank() }
            ?: uri.lastPathSegment?.substringAfterLast('/') ?: "file"
        return n to size
    }

    private fun stream(ctx: Context, uri: Uri): InputStream =
        ctx.contentResolver.openInputStream(uri) ?: throw Fail("Tidak bisa membuka file")

    private fun InputStream.fill(buf: ByteArray): Int {
        var t = 0
        while (t < buf.size) {
            val n = read(buf, t, buf.size - t)
            if (n < 0) break
            t += n
        }
        return t
    }

    private fun hash(ctx: Context, uri: Uri, known: Long, onPct: (Float) -> Unit): Hashes {
        val full = MessageDigest.getInstance("MD5")
        val head = MessageDigest.getInstance("MD5")
        val cur = MessageDigest.getInstance("MD5")
        val blocks = ArrayList<String>()
        var total = 0L
        var inChunk = 0
        var headLeft = SLICE
        var lastPct = -1

        stream(ctx, uri).use { ins ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                full.update(buf, 0, n)
                val s = minOf(n, headLeft)
                if (s > 0) {
                    head.update(buf, 0, s)
                    headLeft -= s
                }
                var off = 0
                while (off < n) {
                    val take = minOf(n - off, CHUNK - inChunk)
                    cur.update(buf, off, take)
                    off += take
                    inChunk += take
                    if (inChunk == CHUNK) {
                        blocks.add(hex(cur.digest()))
                        inChunk = 0
                    }
                }
                total += n
                if (known > 0) {
                    val p = (total * 100 / known).toInt().coerceAtMost(100)
                    if (p != lastPct) {
                        lastPct = p
                        onPct(p / 100f)
                    }
                }
            }
        }
        if (inChunk > 0) blocks.add(hex(cur.digest()))
        return Hashes(total, hex(full.digest()), hex(head.digest()), blocks)
    }

    private fun hex(b: ByteArray): String = b.joinToString("") { "%02x".format(it) }
}

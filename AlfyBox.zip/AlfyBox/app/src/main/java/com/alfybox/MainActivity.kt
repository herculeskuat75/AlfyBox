package com.alfybox

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { Screen() }
            }
        }
    }
}

@Composable
private fun Screen() {
    val ctx = LocalContext.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("alfybox", Context.MODE_PRIVATE) }

    var cookie by remember { mutableStateOf(prefs.getString("cookie", "") ?: "") }
    var uri by remember { mutableStateOf<Uri?>(null) }
    var name by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var status by remember { mutableStateOf("") }

    DisposableEffect(busy) {
        view.keepScreenOn = busy
        onDispose { view.keepScreenOn = false }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            uri = u
            name = Terabox.fileName(ctx, u)
            status = ""
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().systemBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("AlfyBox", style = MaterialTheme.typography.headlineMedium)

        OutlinedTextField(
            value = cookie,
            onValueChange = {
                cookie = it
                prefs.edit().putString("cookie", it).apply()
            },
            label = { Text("Cookie Terabox") },
            placeholder = { Text("ndus=...") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3,
            maxLines = 5,
            enabled = !busy
        )

        Button(onClick = { picker.launch(arrayOf("*/*")) }, enabled = !busy) {
            Text("Pilih File")
        }
        if (name.isNotEmpty()) Text(name)

        Button(
            enabled = !busy && uri != null && cookie.isNotBlank(),
            onClick = {
                val u = uri ?: return@Button
                busy = true
                progress = -1f
                status = "Mulai…"
                scope.launch {
                    val r = Terabox.upload(ctx, u, cookie) { s, p ->
                        status = s
                        progress = p
                    }
                    busy = false
                    r.onSuccess {
                        status = it
                        Toast.makeText(ctx, "Upload berhasil", Toast.LENGTH_LONG).show()
                    }.onFailure {
                        val msg = it.message ?: "Terjadi kesalahan"
                        status = msg
                        Toast.makeText(ctx, "Upload gagal: $msg", Toast.LENGTH_LONG).show()
                    }
                }
            }
        ) { Text("Upload") }

        if (busy) {
            if (progress < 0f) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
            } else {
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
            }
        }
        if (status.isNotEmpty()) Text(status)
    }
}
